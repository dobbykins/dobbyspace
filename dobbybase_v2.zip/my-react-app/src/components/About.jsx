import styles from './About.module.css'

// ↓ Edit your skills list here
const skills = ['Java', 'JavaScript', 'React', 'HTML', 'CSS', 'Git']

export default function About() {
  return (
    <section id="about" className={styles.about}>
      <h2 className={styles.heading}>About me</h2>
      <div className={styles.content}>
        <div className={styles.bio}>
          {/* ↓ Replace this with your actual bio */}
          <p>
            I'm a developer with a background in Java, now exploring the web
            with React. I care about writing clean, readable code and building
            things that are actually useful.
          </p>
          <p>
            When I'm not coding, you can usually find me [your hobby here].
          </p>
        </div>
        <div className={styles.skills}>
          <h3>Technologies</h3>
          <ul className={styles.skillList}>
            {skills.map(skill => (
              <li key={skill} className={styles.skill}>{skill}</li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  )
}
