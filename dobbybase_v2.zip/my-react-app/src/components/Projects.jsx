import styles from './Projects.module.css'

// ↓ Add / remove / edit your projects here
const projects = [
  {
    title: 'Project One',
    description: 'A short description of what this project does and what you learned building it.',
    tags: ['React', 'CSS'],
    link: '#',
  },
  {
    title: 'Project Two',
    description: 'Another project. What problem did it solve? What tech did you use?',
    tags: ['Java', 'API'],
    link: '#',
  },
  {
    title: 'Project Three',
    description: 'Keep descriptions concise — one or two sentences is enough.',
    tags: ['HTML', 'CSS'],
    link: '#',
  },
]

function ProjectCard({ title, description, tags, link }) {
  return (
    <article className={styles.card}>
      <h3 className={styles.cardTitle}>{title}</h3>
      <p className={styles.cardDesc}>{description}</p>
      <div className={styles.cardFooter}>
        <ul className={styles.tags}>
          {tags.map(tag => <li key={tag} className={styles.tag}>{tag}</li>)}
        </ul>
        <a href={link} className={styles.cardLink}>View →</a>
      </div>
    </article>
  )
}

export default function Projects() {
  return (
    <section id="projects" className={styles.projects}>
      <h2 className={styles.heading}>Projects</h2>
      <div className={styles.grid}>
        {projects.map(p => <ProjectCard key={p.title} {...p} />)}
      </div>
    </section>
  )
}
