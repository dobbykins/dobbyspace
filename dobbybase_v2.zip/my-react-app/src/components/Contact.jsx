import styles from './Contact.module.css'

// ↓ Add your real links here
const socials = [
  { label: 'GitHub',   href: 'https://github.com/' },
  { label: 'LinkedIn', href: 'https://linkedin.com/in/' },
  { label: 'Email',    href: 'mailto:you@example.com' },
]

export default function Contact() {
  return (
    <section id="contact" className={styles.contact}>
      <h2 className={styles.heading}>Get in touch</h2>
      <p className={styles.body}>
        I'm open to opportunities, collaborations, or just a good conversation.
        Reach out through any of the links below.
      </p>
      <ul className={styles.links}>
        {socials.map(({ label, href }) => (
          <li key={label}>
            <a href={href} className={styles.link} target="_blank" rel="noreferrer">
              {label} →
            </a>
          </li>
        ))}
      </ul>
    </section>
  )
}
